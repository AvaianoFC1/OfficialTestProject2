package com.test.MainCalc;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.test.MainCalc.R;

public class Page1 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstaceState) {
        super.onCreate(savedInstaceState);
        setContentView(R.layout.page1layout);
    }
}
